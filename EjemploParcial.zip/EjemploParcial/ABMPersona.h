#pragma once
#include "Persona.h"

class ABMPersona
{
private:
	string nomArchivo;
	Persona* persona;
public:
	ABMPersona(string _nA);
	void Agregar(Persona*);
	void Mostrar_Reg(int);
	void Adicionar_Nuevo();
	void Listar();
	int Buscar_Reg();
	void Eliminar_Reg();
	void Modificar_Reg();
};