#include "Persona.h"

Persona::Persona() {
	codigo = 0;
	nombre = "";
	apellido = "";
	fecha_nacimiento = "";
	genero = ' ';
	direccion = "";
	telefono = "";
	estado = ' ';
}

Persona::Persona(int _c, string _n, string _a, string _fn, char _g, string _d, string _t) {
	codigo = _c;
	nombre = _n;
	apellido = _a;
	fecha_nacimiento = _fn;
	genero = _g;
	direccion = _d;
	telefono = _t;
	estado = 'A';
}

void Persona::set_persona(int _c, string _n, string _a, string _fn, char _g, string _d, string _t) {
	codigo = _c;
	nombre = _n;
	apellido = _a;
	fecha_nacimiento = _fn;
	genero = _g;
	direccion = _d;
	telefono = _t;
	estado = 'A';
}

int Persona::get_codigo() {
	return codigo;
}

string Persona::get_nombre() {
	return nombre;
}

string Persona::get_apellido() {
	return apellido;
}

string Persona::get_fechaNacimiento() {
	return fecha_nacimiento;
}

char Persona::get_genero() {
	return genero;
}

string Persona::get_direccion() {
	return direccion;
}

string Persona::get_telefono() {
	return telefono;
}

char Persona::get_estado() {
	return estado;
}

void Persona::Guardar_Archivo(ofstream& archivo) {
	archivo.write(reinterpret_cast<char*>(&codigo), sizeof(codigo));
	archivo.write(reinterpret_cast<char*>(&nombre), sizeof(nombre));
	archivo.write(reinterpret_cast<char*>(&apellido), sizeof(apellido));
	archivo.write(reinterpret_cast<char*>(&fecha_nacimiento), sizeof(fecha_nacimiento));
	archivo.write(reinterpret_cast<char*>(&genero), sizeof(genero));
	archivo.write(reinterpret_cast<char*>(&direccion), sizeof(direccion));
	archivo.write(reinterpret_cast<char*>(&telefono), sizeof(telefono));
	archivo.write(reinterpret_cast<char*>(&estado), sizeof(estado));
}

bool Persona::Leer_Archivo(ifstream& archivo2) {
	bool a = false;
	if (archivo2.is_open()) {
		archivo2.read(reinterpret_cast<char*>(&nombre), sizeof(nombre));
		if (!archivo2.eof()) {
			archivo2.read(reinterpret_cast<char*>(&codigo), sizeof(codigo));
			archivo2.read(reinterpret_cast<char*>(&apellido), sizeof(apellido));
			archivo2.read(reinterpret_cast<char*>(&fecha_nacimiento), sizeof(fecha_nacimiento));
			archivo2.read(reinterpret_cast<char*>(&genero), sizeof(genero));
			archivo2.read(reinterpret_cast<char*>(&direccion), sizeof(direccion));
			archivo2.read(reinterpret_cast<char*>(&telefono), sizeof(telefono));
			archivo2.read(reinterpret_cast<char*>(&estado), sizeof(estado));
			a = true;
		}
		else {
			cout << endl << "Registro no existe";
		}
	}
	else {
		cout << endl << "Arhivo no existe";
	}
	return a;
}

bool Persona::Eliminar(fstream& archivo3, int nro) {
	bool a = false;
	if (archivo3.is_open()) {
		archivo3.seekg(getTamBytesReg() * (nro - 1), ios::beg);
		archivo3.read(reinterpret_cast<char*>(&nombre), sizeof(nombre));
		if (!archivo3.eof()) {
			archivo3.read(reinterpret_cast<char*>(&codigo), sizeof(codigo));
			archivo3.read(reinterpret_cast<char*>(&apellido), sizeof(apellido));
			archivo3.read(reinterpret_cast<char*>(&fecha_nacimiento), sizeof(fecha_nacimiento));
			archivo3.read(reinterpret_cast<char*>(&genero), sizeof(genero));
			archivo3.read(reinterpret_cast<char*>(&direccion), sizeof(direccion));
			archivo3.read(reinterpret_cast<char*>(&telefono), sizeof(telefono));
			archivo3.read(reinterpret_cast<char*>(&estado), sizeof(estado));

			estado = 'E';
			archivo3.seekp(getTamBytesReg() * (nro - 1), ios::beg);
			archivo3.write(reinterpret_cast<char*>(&codigo), sizeof(codigo));
			archivo3.write(reinterpret_cast<char*>(&nombre), sizeof(nombre));
			archivo3.write(reinterpret_cast<char*>(&apellido), sizeof(apellido));
			archivo3.write(reinterpret_cast<char*>(&fecha_nacimiento), sizeof(fecha_nacimiento));
			archivo3.write(reinterpret_cast<char*>(&genero), sizeof(genero));
			archivo3.write(reinterpret_cast<char*>(&direccion), sizeof(direccion));
			archivo3.write(reinterpret_cast<char*>(&telefono), sizeof(telefono));
			archivo3.write(reinterpret_cast<char*>(&estado), sizeof(estado));
			a = true;
		}
		else {
			cout << endl << "Registro no existe";
		}
	}
	else {
		cout << endl << "Arhivo no existe";
	}
	return a;
}

bool Persona::Modificar(fstream& archivo4, int nro) {
	bool a = false;
	if (archivo4.is_open()) {
		string nomAux;
		nomAux = nombre;
		archivo4.seekg(getTamBytesReg() * (nro - 1), ios::beg);
		archivo4.read(reinterpret_cast<char*>(&nombre), sizeof(nombre));
		if (!archivo4.eof()) {
			nombre = nomAux;
			estado = 'A';
			archivo4.seekp(getTamBytesReg() * (nro - 1), ios::beg);
			archivo4.write(reinterpret_cast<char*>(&codigo), sizeof(codigo));
			archivo4.write(reinterpret_cast<char*>(&nombre), sizeof(nombre));
			archivo4.write(reinterpret_cast<char*>(&apellido), sizeof(apellido));
			archivo4.write(reinterpret_cast<char*>(&fecha_nacimiento), sizeof(fecha_nacimiento));
			archivo4.write(reinterpret_cast<char*>(&genero), sizeof(genero));
			archivo4.write(reinterpret_cast<char*>(&direccion), sizeof(direccion));
			archivo4.write(reinterpret_cast<char*>(&telefono), sizeof(telefono));
			archivo4.write(reinterpret_cast<char*>(&estado), sizeof(estado));
			a = true;
		}
		else {
			cout << endl << "Registro no existe";
		}
	}
	else {
		cout << endl << "Arhivo no existe";
	}
	return a;
}

bool Persona::Buscar(ifstream& archivo5, int nro) {
	bool a = false;
	if (archivo5.is_open()) {
		archivo5.seekg(getTamBytesReg() * (nro - 1), ios::beg);
		archivo5.read(reinterpret_cast<char*>(&codigo), sizeof(codigo));
		archivo5.read(reinterpret_cast<char*>(&nombre), sizeof(nombre));
		archivo5.read(reinterpret_cast<char*>(&apellido), sizeof(apellido));
		archivo5.read(reinterpret_cast<char*>(&fecha_nacimiento), sizeof(fecha_nacimiento));
		archivo5.read(reinterpret_cast<char*>(&genero), sizeof(genero));
		archivo5.read(reinterpret_cast<char*>(&direccion), sizeof(direccion));
		archivo5.read(reinterpret_cast<char*>(&telefono), sizeof(telefono));
		archivo5.read(reinterpret_cast<char*>(&estado), sizeof(estado));
		if (archivo5.eof()) {
			a = true;
		}
		else {
			cout << endl << "Registro no XX existe";
		}
	}
	else {
		cout << endl << "Arhivo no existe";
	}
	return a;
}

int Persona::getTamBytesReg() {
	return (sizeof(codigo) + sizeof(nombre) + sizeof(apellido) + sizeof(fecha_nacimiento) + sizeof(genero) + sizeof(direccion) + sizeof(telefono) + sizeof(estado));
}