#pragma once
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class Persona
{
private:
	int codigo;
	string nombre;
	string apellido;
	string fecha_nacimiento;
	char genero;
	string direccion;
	string telefono;
	char estado;
public:
	Persona();
	Persona(int _c, string _n, string _a, string _fn, char _g, string _d, string _t);
	void set_persona(int _c, string _n, string _a, string _fn, char _g, string _d, string _t);
	int get_codigo();
	string get_nombre();
	string get_apellido();
	string get_fechaNacimiento();
	char get_genero();
	string get_direccion();
	string get_telefono();
	char get_estado();
	void Guardar_Archivo(ofstream&);
	bool Leer_Archivo(ifstream&);
	bool Eliminar(fstream&, int);
	bool Modificar(fstream&, int);
	bool Buscar(ifstream&, int);
	int getTamBytesReg();
};