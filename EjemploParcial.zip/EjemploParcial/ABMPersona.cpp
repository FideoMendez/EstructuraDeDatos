#include "ABMPersona.h"

ABMPersona::ABMPersona(string _nA) {
	nomArchivo = _nA;
}

void ABMPersona::Agregar(Persona* nuevoReg) {
	int codigo;
	string nombre, apellido, fecha_nacimiento, direccion, telefono;
	char genero;
	cout << "Ingrese los datos de la persona: " << endl;
	cout << "Codigo: ";
	cin >> codigo;
	cin.ignore();
	cout << "Nombre: ";
	getline(cin, nombre);
	cout << "Apellido: ";
	getline(cin, apellido);
	cout << "Fecha de nacimiento: ";
	getline(cin, fecha_nacimiento);
	cout << "Genero M/F/O: ";
	cin >> genero;
	cin.ignore();
	cout << "Direccion: ";
	getline(cin, direccion);
	cout << "Telefono: ";
	getline(cin, telefono);
	nuevoReg->set_persona(codigo, nombre, apellido, fecha_nacimiento, genero, direccion, telefono);
}

void ABMPersona::Mostrar_Reg(int nro) {
	cout << endl << nro << ".- " << persona->get_codigo() << " " << persona->get_nombre() << " " << persona->get_apellido() << " " << persona->get_fechaNacimiento() << " " << persona->get_genero() << " " << persona->get_direccion() << " " << persona->get_telefono(); 
}

void ABMPersona::Adicionar_Nuevo() {
	ofstream archivo(nomArchivo, ios::app | ios::binary);
	persona = new Persona();
	Agregar(persona); 
	int nroReg = archivo.tellp() / persona->getTamBytesReg() + 1;
	persona->Guardar_Archivo(archivo);
	archivo.close();
}

void ABMPersona::Listar() {
	int reg = 0;
	cout << endl << "Los registros son: " << endl;
	persona = new Persona();
	ifstream archivo2(nomArchivo, ios::in | ios::binary);
	while (persona->Leer_Archivo(archivo2)) {
		reg++;
		if (persona->get_estado() == 'A') {
			Mostrar_Reg(reg);
		}
	}
	archivo2.close();
}

int ABMPersona::Buscar_Reg() {
	int nro;
	cout << endl << endl << "Introducir numero de registro a buscar :  ";
	cin >> nro;
	cin.ignore();
	persona = new Persona();
	ifstream archivo3(nomArchivo, ios::in | ios::binary);
	if (persona->Buscar(archivo3, nro) == true) {
		Mostrar_Reg(nro);
	}
	else {
		cout << endl << "Registro no existe";
		nro = -1;
	}
	archivo3.close();
	return(nro);
}

void ABMPersona::Eliminar_Reg() {
	int nro;
	nro = Buscar_Reg();
	if (nro > 0) {
		fstream archivo4(nomArchivo, ios::in | ios::out | ios::binary);
		persona = new Persona();
		if (persona->Eliminar(archivo4, nro) == true) {
			cout << endl << "Registro eliminado correctmente " << endl;
		}
		else {
			cout << endl << "Registro no existe pa eliminar" << endl;
		}
		archivo4.close();
	}
}

void ABMPersona::Modificar_Reg() {
	int nro;
	nro = Buscar_Reg();
	if (nro > 0) {
		fstream archivo5(nomArchivo, ios::in | ios::out | ios::binary);
		persona = new Persona();
		Agregar(persona);
		if (persona->Modificar(archivo5, nro) == true) {
			cout << endl << "modificado correctamente... " << endl;
		}
		else {
			cout << endl << "Registro no existe pa modificar";
		}
		archivo5.close();
	}
}