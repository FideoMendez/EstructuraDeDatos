#include "ABMPersona.h"

int main()
{
    ABMPersona* persona = new ABMPersona("persona.bin");
    int opcion;

    do {
        cout << "--- MENU ---" << endl;
        cout << "1. Adicionar nuevo registro" << endl;
        cout << "2. Listar registros" << endl;
        cout << "3. Buscar registro" << endl;
        cout << "4. Eliminar registro" << endl;
        cout << "5. Modificar registro" << endl;
        cout << "6. Salir" << endl;
        cout << "Ingrese opcion: ";
        cin >> opcion;
        cin.ignore();
        switch (opcion) {
        case 1:
            persona->Adicionar_Nuevo();
            break;
        case 2:
            persona->Listar();
            break;
        case 3:
            persona->Buscar_Reg();
            break;
        case 4:
            persona->Eliminar_Reg();
            break;
        case 5:
            persona->Modificar_Reg();
            break;
        case 6:
            cout << "Saliendo del programa..." << endl;
            break;
        default:
            cout << "Opción inválida. Intente de nuevo." << endl;
            break;
        }
    } while (opcion != 6);

	return 0;
}