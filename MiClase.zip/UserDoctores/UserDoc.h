#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include "DatosDocs.h"

using namespace std;

class UserDoc
{
private: // propiedades
    string nombre;
    int edad;
    string sexo;
    char estado;        //eliminado = E, activo = A
public: // m�todos
    UserDoc();
    UserDoc(string nom, int ed, string sx);
    void setDoc(string nom, int ed, string sx);
    string getNombre();
    int getEdad();
    string getSexo();
    char getEstado();
    void guardarArchivo(ofstream& fsalida);
    bool leerArchivo(ifstream& fentrada);
    bool eliminar(fstream& fes, int nroReg);
    bool modificar(fstream& fes, int nroReg);
    bool buscar(ifstream& fentrada, int nroReg);
    int getTamBytesRegistro();
};