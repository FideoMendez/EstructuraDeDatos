#include <iostream>
#include <string>
#include <fstream>
#include "DatosDocs.h"
#include "UserDoc.h"

using namespace std;

int main()
{
    DatosDocs* Doc = new DatosDocs("Doctores.dat");
    int opcion;
    do {
        Doc->mostrarMenu();
        cin >> opcion;
        switch (opcion) {
        case 1:
            Doc->adicionarNuevo();
            break;
        case 2:
            cout << "Listado" << endl;
            Doc->listar();
            break;
        case 3:
            Doc->buscarReg();
            break;
        case 4:
            Doc->eliminarReg();
            break;
        case 5:
            Doc->modificarReg();
            break;
        case 6:
            cout << "Saliendo del programa..." << endl;
            break;
        default:
            cout << "Opci�n no v�lida. Int�ntalo de nuevo." << endl;
        }
    } while (opcion != 6);

	return 0;
}