#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include "UserDoc.h"

using namespace std;

class DatosDocs
{
private:
    string  nomArchivo;
    UserDoc* Docs;
public:
    DatosDocs(string nomArch);
    void introducirDatos(UserDoc* newReg);
    void mostrarRegistro(int nroReg);
    void adicionarNuevo();
    void listar();
    int buscarReg();
    void eliminarReg();
    void modificarReg();
    void mostrarMenu();
};