#include <iostream>
#include <string>
#include <fstream>
#include "DatosDocs.h"
#include "UserDoc.h"

using namespace std;

DatosDocs::DatosDocs(string nomArch) {
    nomArchivo = nomArch;
}

void DatosDocs::introducirDatos(UserDoc* newReg) {
    string nombre;
    int edad;
    string sexo;
    cout << endl << "Introducir los siguientes datos --->>> :" << endl;
    cin.ignore();
    cout << "Nombre : ";
    getline(cin, nombre);
    cout << "Edad : ";
    cin >> edad;
    cout << "Sexo <Femenino/Masculino>: ";
    cin >> sexo;
    newReg->setDoc(nombre, edad, sexo);    //CAMBIAR PARA EL PROYECTO
}

void DatosDocs::mostrarRegistro(int nroReg) {
    cout << endl << nroReg << ".-  " << Docs->getNombre() << "  " << Docs->getEdad() << "  " << Docs->getSexo() << "  " << Docs->getEstado();
}

void DatosDocs::adicionarNuevo() {
    ofstream fsalida(nomArchivo, ios::app | ios::binary);
    Docs = new UserDoc();
    introducirDatos(Docs);
    Docs->guardarArchivo(fsalida);
    fsalida.close();
}

void DatosDocs::listar() {
    int cr = 0;
    cout << endl << "Los registros son --->>> : " << endl;
    Docs = new UserDoc();
    ifstream fentrada(nomArchivo, ios::in | ios::binary);
    while (Docs->leerArchivo(fentrada) == true) {
        cr++;
        if (Docs->getEstado() == 'A') {
            mostrarRegistro(cr);
        }
    }
    fentrada.close();
}

int DatosDocs::buscarReg() {
    int nroReg;
    cout << endl << endl << "Introducir numero de registro a buscar :  ";
    cin >> nroReg;
    Docs = new UserDoc();
    ifstream fentrada(nomArchivo, ios::in | ios::binary);
    if (Docs->buscar(fentrada, nroReg) == true) {
        mostrarRegistro(nroReg);
    }
    else {
        cout << endl << "Registro no existe";
        nroReg = -1;
    }
    fentrada.close();
    return(nroReg);
}

void DatosDocs::eliminarReg() {
    int nroReg;
    nroReg = buscarReg();
    if (nroReg > 0) {
        fstream fes(nomArchivo, ios::in | ios::out | ios::binary);
        Docs = new UserDoc();
        if (Docs->eliminar(fes, nroReg) == true) {
            cout << endl << "Registro eliminado correctmente " << endl;
        }
        else {
            cout << endl << "Registro no existe pa eliminar" << endl;
        }
        fes.close();
    }
}

void DatosDocs::modificarReg() {
    int nroReg;
    nroReg = buscarReg();
    if (nroReg > 0) {
        fstream fes(nomArchivo, ios::in | ios::out | ios::binary);
        Docs = new UserDoc();
        introducirDatos(Docs);
        if (Docs->modificar(fes, nroReg) == true) {
            cout << endl << "modificado correctamente... " << endl;
        }
        else {
            cout << endl << "Registro no existe pa modificar";
        }
        fes.close();
    }
}

void DatosDocs::mostrarMenu() {
    cout << "***** FORO DEL DOCTOR *****" << endl;
    cout << "1. Introducir nuevo doctor" << endl;
    cout << "2. Mostrar todos los doctores" << endl;
    cout << "3. Buscar doctor" << endl;
    cout << "4. Eliminar doctor" << endl;
    cout << "5. Modificar doctor" << endl;
    cout << "6. Salir" << endl;
    cout << "Selecciona una opci�n: ";
}