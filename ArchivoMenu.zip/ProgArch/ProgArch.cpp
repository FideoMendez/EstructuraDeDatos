#include <iostream>
#include <fstream>
#include "ABMamigo.h"

using namespace std;

int main() {
    ABMamigo* amig = new ABMamigo("amigOO.dat");
    amig->mostrarMenu();
    delete amig;

    return 0;
}