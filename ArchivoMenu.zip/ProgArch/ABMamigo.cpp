#include <iostream>
#include <fstream>
#include <string>
#include "ABMamigo.h"
#include "Amigo.h"

using namespace std;


ABMamigo::ABMamigo(string nomArch) {
    nomArchivo = nomArch;
}

void ABMamigo::introducirDatos(Amigo* newReg) {
    string nombre;
    int edad;
    char sexo;
    cout << endl << endl << "Introducir los siguientes datos --->>> :" << endl;
    fflush(stdin);
    cout << "Nombre : ";
    getline(cin, nombre);
    cout << "Edad : ";
    cin >> edad;
    cout << "Sexo <F/M>: ";
    cin >> sexo;
    newReg->setAmigo(nombre, edad, sexo);
}

void ABMamigo::mostrarRegistro(int nroReg) {
    cout << endl << nroReg << ".-  " << amig->getNombre() << "  " << amig->getEdad() << "  " << amig->getSexo() << "  " << amig->getEstado();
}

void ABMamigo::adicionarNuevo() {
    ofstream fsalida(nomArchivo, ios::app | ios::binary);
    amig = new Amigo();
    introducirDatos(amig);
    int nroReg = fsalida.tellp() / amig->getTamBytesRegistro() + 1; // Calcular el n�mero de registro
    cout << endl << "Registro agregado correctamente. N�mero de registro: " << nroReg << endl;
    amig->guardarArchivo(fsalida);
    fsalida.close();
}

void ABMamigo::listar() {
    int cr = 0;
    cout << endl << endl << "Los registros son --->>> : " << endl;
    amig = new Amigo();
    ifstream fentrada(nomArchivo, ios::in | ios::binary);
    while (amig->leerArchivo(fentrada)) {
        cr++;
        if (amig->getEstado() == 'A')
            mostrarRegistro(cr);
    }
    fentrada.close();
    cout << "\nPresione Enter para volver al men�...";
    cin.ignore(); // Esperar la pulsaci�n de Enter para volver al men�
    cin.get();
}

int ABMamigo::buscarReg() {
    int nroReg;
    cout << endl << endl << "Introducir numero de registro a buscar :  ";
    cin >> nroReg;
    cin.ignore();
    amig = new Amigo();
    ifstream fentrada(nomArchivo, ios::in | ios::binary);
    if (amig->buscar(fentrada, nroReg)) {
        mostrarRegistro(nroReg);
        fentrada.close();
        return nroReg;
    }
    else {
        cout << endl << "Registro no existe";
        fentrada.close();
        return -1;
    }
}

void ABMamigo::eliminarReg() {
    int nroReg;
    nroReg = buscarReg();
    if (nroReg > 0) {
        fstream fes(nomArchivo, ios::in | ios::out | ios::binary);
        amig = new Amigo();
        if (amig->eliminar(fes, nroReg))
            cout << endl << "Registro eliminado correctamente " << endl;
        else
            cout << endl << "Registro no existe para eliminar" << endl;
        fes.close();
    }
}

void ABMamigo::modificarReg() {
    int nroReg;
    nroReg = buscarReg();
    if (nroReg > 0) {
        fstream fes(nomArchivo, ios::in | ios::out | ios::binary);
        amig = new Amigo();
        introducirDatos(amig);
        if (amig->modificar(fes, nroReg))
            cout << endl << "Modificado correctamente... " << endl;
        else
            cout << endl << "Registro no existe para modificar";
        fes.close();
    }
}

void ABMamigo::mostrarMenu() {
    int opcion;
    do {
        cout << "\n\n--- MENU ---" << endl;
        cout << "1. Adicionar nuevo registro" << endl;
        cout << "2. Listar registros" << endl;
        cout << "3. Buscar registro" << endl;
        cout << "4. Eliminar registro" << endl;
        cout << "5. Modificar registro" << endl;
        cout << "6. Salir" << endl;
        cout << "Ingrese opcion: ";
        cin >> opcion;
        cin.ignore();
        switch (opcion) {
        case 1:
            adicionarNuevo();
            break;
        case 2:
            listar();
            break;
        case 3:
            buscarReg();
            break;
        case 4:
            eliminarReg();
            break;
        case 5:
            modificarReg();
            break;
        case 6:
            cout << "Saliendo del programa..." << endl;
            break;
        default:
            cout << "Opci�n inv�lida. Intente de nuevo." << endl;
            break;
        }
    } while (opcion != 6);
}